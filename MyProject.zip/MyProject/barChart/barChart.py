import numpy as np
import matplotlib.pyplot as plt
###############################################################################
plt.rc('font', family='Malgun Gothic')
cnt, PNG, UNDERBAR = 0, '.png', '_'
CHART_NAME = 'barChart'
filename = '기간별시세변화.csv'
###############################################################################
import pandas as pd

data = pd.read_csv(filename)

print(data.columns)
print('-'*30)

chartdata = data['2021년5월22일']
print(chartdata)
print('-'*30)
print('type(chartdata)')
print(type(chartdata)) # Series
###############################################################################
# plt.bar() 메소드를 사용한 막대 그래프
def MakeBarChart01(x, y, color, xlabel, ylabel, title):
    plt.figure()
    plt.bar(x, y, color=color, alpha=0.7)

    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)

    YTICKS_INTERVAL = 50000

    maxlim = (int(y.max() / YTICKS_INTERVAL) + 1) * YTICKS_INTERVAL
    print(maxlim)

    values = np.arange(0, maxlim + 1, YTICKS_INTERVAL)

    plt.yticks(values, ['%s' % format(val, ',') for val in values])

    # 그래프 위에 건수와 비율 구하기
    ratio = 100 * y / y.sum()
    print(ratio)
    print('-' * 40)

    plt.rc('font', size=6)
    for idx in range(y.size):
        value = format(y[idx], ',') + '원'  # 예시 : 60건
        ratioval = '%.1f%%' % (ratio[idx])  # 예시 : 20.0%
        plt.text(x=idx, y=y[idx] + 1, s=value, horizontalalignment='center')
        if idx == 1:
            pass
        else:
            plt.text(x=idx, y=y[idx] / 2, s=ratioval, horizontalalignment='center')
    meanval = y.mean()
    print(meanval)
    print('-' * 40)

    average = '평균 : %d원' % meanval
    plt.axhline(y=meanval, color='r', linewidth=1, linestyle='dashed')
    plt.text(x=y.size - 1, y=meanval + 200, s=average, horizontalalignment='center')
    plt.ylabel('가격(원)')
    global cnt
    cnt = cnt + 1
    savefile = CHART_NAME + UNDERBAR + str(cnt).zfill(2) + PNG
    plt.savefig(savefile, dpi=400)
    print(savefile + ' 파일이 저장되었습니다.')
# def MakeBarChart01
###############################################################################

colors = ['b', 'g', 'r', 'c', 'm', 'y', 'k']

mycolor = colors[0:len(chartdata)]


MakeBarChart01(x=['금','은','다이아몬드','백금'], y=chartdata, color=mycolor, xlabel='보석명', ylabel='가격(원)',
               title='2021년5월22일 보석별 시세비교')
###############################################################################






def MakeBarChart02(chartdata, rotation, title, ylim=None, stacked=False, yticks_interval = 50000):
    plt.figure()
    chartdata.plot(kind='bar', rot=rotation, title=title, legend=True, stacked=stacked)

    plt.legend(loc='best')

    print('chartdata')
    print(chartdata)

    if stacked == False :
        maxlim = (int(max(chartdata.max()) / yticks_interval) + 1) * yticks_interval
        print('maxlim : ', maxlim)
        values = np.arange(0, maxlim + 1, yticks_interval)
        plt.yticks(values, ['%s' % format(val, ',') for val in values])
    else :
        maxlim = (int(max(chartdata.sum(axis=1)) / yticks_interval) + 1) * yticks_interval
        print('maxlim : ', maxlim)
        values = np.arange(0, maxlim + 1, yticks_interval)
        plt.yticks(values, ['%s' % format(val, ',') for val in values])
    # plt.yscale('log')
    plt.ylabel('가격(원)')
    if ylim != None :
        plt.ylim(ylim)
    global cnt
    cnt = cnt + 1
    savefile = CHART_NAME + UNDERBAR + str(cnt).zfill(2) + PNG
    plt.savefig(savefile, dpi=400)
    print(savefile + ' 파일이 저장되었습니다.')

data = pd.read_csv(filename, index_col='종류')
print(data.columns)
print('-' * 30)

COUNTRY = ['금', '은', '다이아몬드', '백금']
WHEN = ['2021년5월22일', '2020년5월22일', '2019년5월22일', '2018년5월22일']
data = data.loc[COUNTRY, WHEN]

print(data)
print('-'*30)

data.index.name = '보석 종류'
data.columns.name = '일자'

MakeBarChart02(chartdata=data, rotation=0, title='보석별 4년간 시세변화' )
