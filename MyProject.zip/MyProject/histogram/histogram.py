import pandas as pd
import matplotlib.pyplot as plt


################################################
plt.rc('font', family='Malgun Gothic')
cnt, PNG, UNDERBAR = 0, '.png', '_'
CHART_NAME = 'histogram'
filename = './../histogram/하하하.csv'
##############################################3
tips = pd.read_csv(filename, encoding='utf-8')
print(tips.columns)
print('-'*30)



num_bins = 30
fig, axes = plt.subplots(nrows=1, ncols=4, figsize=(16,8))
plt.subplots_adjust(wspace=0.3)
giant = tips['diamond']
dwarf = tips['gold']
silver = tips['silver']
whitegold = tips['whitegold']
print(giant)
axes[0].hist(giant, range=(400000, 600000), bins=20, alpha=0.6, color='red')
axes[1].hist(dwarf, range=(60000, 70000), bins=20, alpha=0.6, color='orange')
axes[2].hist(silver, range=(1300, 4000), bins=20, alpha=0.6, color='dimgray')
axes[3].hist(whitegold, range=(120000, 160000), bins=20, alpha=0.6)

axes[0].set_title('다이아몬드')
axes[1].set_title('금')
axes[2].set_title('은')
axes[3].set_title('백금')

axes[0].set_xlabel('가격(VVS1)')
axes[1].set_xlabel('가격(g당)')
axes[2].set_xlabel('가격(3.75g당)')
axes[3].set_xlabel('가격(3.75g당)')

for idxs in range(0,4,1):
    axes[idxs].set_ylabel('일수')


cnt += 1
savefile = CHART_NAME + UNDERBAR + str(cnt).zfill(2) + PNG
plt.savefig(savefile, dpi=400)
print(savefile + '파일 저장됨')


fig, axes = plt.subplots()
axes.hist(giant, bins=20, alpha=0.6)
axes.hist(dwarf, bins=20, alpha=0.6)
axes.hist(silver, bins=20, alpha=0.6)
axes.hist(whitegold, bins=20, alpha=0.6)
axes.legend(labels=list(['다이아몬드','금','은','백금']))

axes.set_xscale('log')
axes.set_title('보석별 가격 빈도')
axes.set_xlabel('보석 각 단위별 시세(log로 표시)')
cnt += 1
savefile = CHART_NAME + UNDERBAR + str(cnt).zfill(2) + PNG
plt.savefig(savefile, dpi=400)
print(savefile + '파일 저장됨')