import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
################################################
plt.rc('font', family='Malgun Gothic')
cnt, PNG, UNDERBAR = 0, '.png', '_'
CHART_NAME = 'brokenLine'
filename = '기간별시세변화2.csv'
##############################################3
data = pd.read_csv(filename, index_col='종류')
print(data.columns)
print('-'*30)

print(data)
print('-'*30)

chartdata = data['2021년5월28일']
print(type(chartdata))
print(chartdata)
print('-'*30)

plt.plot(chartdata, color='blue', linestyle='solid', marker='o')

YTICKS_INTERVAL = 50000
maxlim = (int(chartdata.max()/YTICKS_INTERVAL) + 1) * YTICKS_INTERVAL
print(maxlim)

values = np.arange(0, maxlim + 1, YTICKS_INTERVAL)
print(values)

plt.yticks(values, ['%s' % format(val, ',') for val in values])
plt.grid(True)
plt.xlabel('보석명')
plt.ylabel('가격(원)')
plt.title('2021년5월28일 시세 비교')

cnt += 1
savefile = CHART_NAME + UNDERBAR + str(cnt).zfill(2) + PNG
plt.savefig(savefile, dpi=400)
print(savefile + '파일 저장됨')

#############################################################################3


COUNTRY = ['금', '은', '다이아몬드', '백금']
WHEN = ['2021년5월28일', '2020년12월28일', '2020년6월27일', '2020년1월27일', '2019년6월28일', '2019년1월28일', '2018년6월28일']
chartdata = data.loc[COUNTRY, WHEN]
chartdata = chartdata.T
print(chartdata)
print('-'*30)

chartdata.plot(title='some Title', marker='o', rot=0, legend=True, figsize=(10, 6))

plt.grid(True)
plt.xlabel('일자')
plt.ylabel('가격(원)')
plt.title('기간별 시세 변화')
# plt.yscale('log')
cnt += 1
savefile = CHART_NAME + UNDERBAR + str(cnt).zfill(2) + PNG
plt.savefig(savefile, dpi=400)
print(savefile + '파일 저장됨')










