from itertools import count
from GoldUtil import Dayprice
import requests
from bs4 import BeautifulSoup
####################################################
brandName = 'gold'
base_url = 'http://www.exgold.co.kr/spot_price.htm'


####################################################
def getData():
    savedData = []  # 엑셀로 저장할 리스트

    for page_idx in count():
        url = base_url
        url += '?p=%s' % str(page_idx + 1)
        url += '&s_gubun=Au&s_unit=out&s_range=T'
        chknStore = Dayprice(brandName, url)
        webpage = requests.get(url)
        soup = BeautifulSoup(webpage.content, "html.parser")
        mytbody = soup.find_all('tr', attrs={'bgcolor':'#FFFFFF'})
        shopExists = False  # 매장 목록이 없다고 가정

        for mytr in mytbody:
            shopExists = True
            print(page_idx+1)


            try:
                date = mytr.select_one('td:nth-of-type(1)').string
                price = mytr.select_one('td:nth-of-type(6)').string
                print(date, price)
                print('-' * 30)
                # imsi = address.split(' ')
                # sido = imsi[0]
                # gungu = imsi[1]
                # print(store + '  ' + phone )

                savedData.append([brandName, date, price])

            except AttributeError as err:
                print(err)
                shopExists = False
                break

        #         if page_idx == 0 :
        if shopExists == False:
            chknStore.save2Csv(savedData)
            break


####################################################
print(brandName + ' 매장 크롤링 시작')
getData()
print(brandName + ' 매장 크롤링 끝')