import time, datetime, ssl
import pandas as pd
import urllib.request


from selenium import webdriver
from bs4 import BeautifulSoup


class Dayprice():
    myencoding = 'utf-8'

    def getWebDriver(self, cmdJavaScript):
        # cmdJavaScript : 문자열로 구성된 자바 스크립트 커맨드
        print(cmdJavaScript)
        self.driver.execute_script(cmdJavaScript)
        wait = 5
        #self.driver.implicitly_wait( wait )
        time.sleep(wait)
        mypage = self.driver.page_source
        return BeautifulSoup(mypage, 'html.parser')

    def getSoup(self):
        if self.soup == None:
            print('여기는 넌이다')
            return None
        else:
            return BeautifulSoup(self.soup, 'html.parser')
            # return BeautifulSoup(self.soup, 'html.parser', from_encoding="iso-8859-1")

    # def get_request_url(self):
    #     request = urllib.request.Request(self.url)
    #     try:
    #         context = ssl._create_unverified_context()
    #         response = urllib.request.urlopen(request, context=context)
    #         if response.getcode() == 200:
    #             print('[%s] url request success' % datetime.datetime.now())
    #             return response.read().decode(self.myencoding)
    #
    #     except Exception as err:
    #         print(err)
    #         now = datetime.datetime.now()
    #         msg = '[%s] error for url %s' % (now, self.url)
    #         print(msg)
    #         return None

    def save2Csv(self, result):
        mycolum = ['brand','']
        data = pd.DataFrame(result, columns=self.mycolumns)
        data.to_csv(self.brandName + '.csv',
                    encoding='utf-8', index=False)
        print(self.brandName + '파일이 생성됨')

    def _t__ini_(self, brandName, url):
        self.brandName = brandName
        self.url = url

        self.mycolumns = ['brand', 'date', 'price']

        print('생성자 호출됨')
# end class ChickenStore()