import matplotlib
import matplotlib.pyplot as plt
###############################################################################
plt.rc('font', family='Malgun Gothic')
matplotlib.rcParams['axes.unicode_minus'] = False
cnt, PNG, UNDERBAR = 0, '.png', '_'
CHART_NAME = 'pieChartExam'
filename = './../barChart/기간별시세변화.csv'
###############################################################################
import pandas as pd

data = pd.read_csv(filename, index_col='종류')
print(data.columns)
print('-'*30)

my_concern = [item for item in data.index if item in ['금', '은', '다이아몬드', '백금']]
print(my_concern)

data = data.loc[my_concern]

chartdata = data['2021년5월22일']

print(chartdata)
print('-'*30)

print(type(chartdata))
print('-'*30)


mylabel = chartdata.index

print(mylabel)
print('-'*30)

mycolors = ['skyblue', '#6AFF00', 'yellow', '#FF003C']

plt.figure()

plt.pie(chartdata, labels=mylabel, shadow=False, explode=(0, 0.05, 0, 0),
        colors=mycolors, autopct='%1.2f%%', startangle=50, counterclock=False)

plt.grid(True)
plt.legend(loc=4)
plt.xlabel('<보석>')
# plt.ylabel("발생 건수")
plt.title('2021년 5월 22일 시세 비율')

cnt += 1
savefile = CHART_NAME + UNDERBAR + str(cnt).zfill(2) + PNG
plt.savefig(savefile, dpi=400)
print(savefile + ' 파일이 저장되었습니다.')
###############################################################################
import numpy as np
fig, ax = plt.subplots(figsize=(6, 3), subplot_kw=dict(aspect="equal"))

def getLabelFormat(pct, allvals):
    absolute = int(pct/100.*np.sum(allvals))
    return "{:.2f}%\n({:d} 원)".format(pct, absolute)

wedges, texts, autotexts = ax.pie(chartdata, autopct=lambda pct: getLabelFormat(pct, chartdata),
                                  textprops=dict(color="w"))

ax.legend(wedges, mylabel,
          title="보석",
          loc="center left",
          bbox_to_anchor=(1, 0, 0.5, 1))

plt.setp(autotexts, size=5, weight="bold")

ax.set_title('2021년 5월 22일 시세 비율')

cnt += 1
savefile = CHART_NAME + UNDERBAR + str(cnt).zfill(2) + PNG
plt.savefig(savefile, dpi=400)
print(savefile + ' 파일이 저장되었습니다.')
###############################################################################
# figure와 축(axis) 객체
fig = plt.figure(figsize=(9, 5))
ax1 = fig.add_subplot(121)
ax2 = fig.add_subplot(122)
fig.subplots_adjust(wspace=0)

data = pd.read_csv(filename, index_col='종류')

print(data)
print('-'*30)

COUNTRY = ['금', '은', '다이아몬드', '백금'] # 관심 국가 목록
my_concern = [item for item in data.index if item in COUNTRY]
print('my_concern : ', my_concern)
print('-'*30)

data = data.loc[my_concern]

when = ['2021년5월22일', '2020년5월22일', '2019년5월22일', '2018년5월22일'] # 관심 일자 목록
filtered_data = data[when] # 파이 차트에 그려질 데이터

print('filtered_data : \n', filtered_data)
print('-'*30)

pieData = filtered_data.sum(axis=1).values # 보석별 총합

barData = filtered_data.loc['금'].values
barData = barData/sum(barData)

print('pieData : ', pieData)
print('-'*30)

print('barData : ', barData)
print('-'*30)

# pie chart 관련 변수 리스트
explode = [0 for idx in range(len(pieData))]
explode[0] = 0.05
print('explode : ', explode)
print('-'*30)

# rotate so that first wedge is split by the x-axis
# 막대 그래프를 우측에 그릴 것이므로, 시작 각도는 90도로 지정하고 counterclock=False의 값으로 지정하면 좋습니다.
STARTANGLE = 20
print('STARTANGLE : ', STARTANGLE)
print('-'*30)
ax1.pie(pieData, autopct='%1.1f%%', startangle=STARTANGLE,
        labels=COUNTRY, explode=explode, counterclock=False)

# bar chart 관련 변수
xpos = 0
bottom = 0
width = .2
colors = [[.1, .3, .5], [.1, .3, .3], [.1, .3, .7]]
colors = ['r', 'g', 'b', 'y']

for j in range(len(barData)):
    height = barData[j]
    ax2.bar(xpos, height, width, bottom=bottom, color=colors[j])
    ypos = bottom + ax2.patches[j].get_height() / 2
    bottom += height
    ax2.text(xpos, ypos, "%.2f%%" % (ax2.patches[j].get_height() * 100),
             ha='center', fontsize=8, color='w')

ax2.set_title("'" + COUNTRY[0] + "'의 연도별 비율")
ax2.legend((when))
ax2.axis('off')
ax2.set_xlim(- 2.5 * width, 2.5 * width)

# use ConnectionPatch to draw lines between the two plots
# get the wedge data
theta1, theta2 = ax1.patches[0].theta1, ax1.patches[0].theta2
center, r = ax1.patches[0].center, ax1.patches[0].r
bar_height = sum([item.get_height() for item in ax2.patches])

LINE_WIDTH = 2 # 연결선의 두께

from matplotlib.patches import ConnectionPatch

# 상단의 연결선
x = r * np.cos(np.pi / 180 * theta2) + center[0]
y = r * np.sin(np.pi / 180 * theta2) + center[1]
con = ConnectionPatch(xyA=(-width / 2, bar_height), coordsA=ax2.transData,
                      xyB=(x, y), coordsB=ax1.transData)
con.set_color([0, 0, 0])
con.set_linewidth(LINE_WIDTH)
ax2.add_artist(con)

# 하단의 연결선
x = r * np.cos(np.pi / 180 * theta1) + center[0]
y = r * np.sin(np.pi / 180 * theta1) + center[1]
con = ConnectionPatch(xyA=(-width / 2, 0), coordsA=ax2.transData,
                      xyB=(x, y), coordsB=ax1.transData)
con.set_color([0, 0, 0])
ax2.add_artist(con)
con.set_linewidth(LINE_WIDTH)

cnt += 1
savefile = CHART_NAME + UNDERBAR + str(cnt).zfill(2) + PNG
# plt.legend(loc='best')
plt.savefig(savefile, dpi=400)
print(savefile + ' 파일이 저장되었습니다.')
###############################################################################
print('finished')
