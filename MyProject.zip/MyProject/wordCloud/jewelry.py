# encoding = 'utf-8'
import numpy as np
import matplotlib.pyplot as plt

from PIL import Image  # PIL 모듈 공부합시다.
from wordcloud import STOPWORDS
from wordcloud import WordCloud
from wordcloud import ImageColorGenerator

image_file = 'gold.png'

img_file = Image.open(image_file)
# <class 'PIL.PngImagePlugin.PngImageFile'>
print(type(img_file))
print('-' * 40)

mask = np.array(img_file)



print(type(mask))  # <class 'numpy.ndarray'>
print('-' * 40)

plt.figure(figsize=(8, 8))  # 그림 영역 설정

plt.imshow(mask, interpolation='bilinear')
plt.axis('off')  # 축 선과 라벨 없애기

filename = 'graph01.png'
plt.savefig(filename, dpi=400, bbox_inches='tight')
print(filename + ' 파일이 저장되었습니다.')

##########################################################################################

mystopwords = set(STOPWORDS)


print(len(mystopwords))
print(mystopwords)

wc = WordCloud(font_path='C:\\font\\NanumGothicCoding.ttf', background_color='white', max_words=2000, mask=mask,
               stopwords=mystopwords)

stevefile = 'gold.txt'
text = open(stevefile, 'rt', encoding='utf-8')
text = text.read()

wc = wc.generate(text)
print(wc.words_)

plt.figure(figsize=(12, 12))
plt.imshow(wc, interpolation='bilinear')
plt.axis('off')

filename = 'graph02.png'
plt.savefig(filename, dpi=400, bbox_inches='tight')
print(filename + ' 파일이 저장되었습니다.')

######################################################################################

color_file = 'gold.png'
color_mask = np.array(Image.open(color_file))

image_colors = ImageColorGenerator(color_mask)

plt.figure(figsize=(12, 12))
newwc = wc.recolor(color_func=image_colors, random_state=42)
plt.imshow(newwc, interpolation='bilinear')
plt.axis('off')

filename = 'graph03.png'
plt.savefig(filename, dpi=400, bbox_inches='tight')
print(filename + ' 파일이 저장되었습니다.')

# plt.show()
print('작업 종료')